package begineerstutor.s3_bucket_example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import org.json.simple.parser.JSONParser;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestStreamHandler;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ProxyWithStream implements RequestStreamHandler {
	JSONParser parser = new JSONParser();

	public void handleRequest(InputStream inputStream, OutputStream outputStream, Context context) throws IOException {

		LambdaLogger logger = context.getLogger();
		logger.log("Loading Java Lambda handler of ProxyWithStream");
		MyResponse responseJson = new MyResponse();
		String response = "";
		BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

		ObjectMapper objectMapper = new ObjectMapper();

		MyRequest car = objectMapper.readValue(reader, MyRequest.class);

		String data = car.getCity() + "" + car.getName() + "" + car.getTime();

		responseJson.setMsg(data);
		responseJson.setStatus("200");
		response = objectMapper.writeValueAsString(car);
		logger.log(response);
		OutputStreamWriter writer = new OutputStreamWriter(outputStream, "UTF-8");
		writer.write(response);
		writer.close();
	
	}
}