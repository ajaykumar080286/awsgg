package begineerstutor.s3_bucket_example;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.PutItemOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class DynamoDb1 {
	public static void main(String[] args) throws Exception {

		// create table
		//createTable();
		// table description

		//uploadItem();
		// tableDesc();

		// tableUpdate();
		// tableDesc();
		// tableDelete();
		// listOftable();
		additem();
	}

	private static void uploadItem() throws Exception {

		AWSCredentials credentials = new BasicAWSCredentials("AKIAJNEH32XXZTKK37IQ",
				"bQZMynrjQZr++pEGZWmzocPYBfEWToZBoIgMnnaI");

		AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
				.withCredentials(new AWSStaticCredentialsProvider(credentials)).withRegion(Regions.AP_SOUTH_1).build();
		DynamoDB dynamoDB = new DynamoDB(client);
		Table table = dynamoDB.getTable("Movies");

		JsonParser parser = new JsonFactory().createParser(new File("E://DOWNLOADS/moviedata.json"));

		JsonNode rootNode = new ObjectMapper().readTree(parser);
		Iterator<JsonNode> iter = rootNode.iterator();

		ObjectNode currentNode;

		while (iter.hasNext()) {
			currentNode = (ObjectNode) iter.next();

			int year = currentNode.path("year").asInt();
			String title = currentNode.path("title").asText();

			try {
				table.putItem(new Item().withPrimaryKey("year", year, "title", title).withJSON("info",
						currentNode.path("info").toString()));
				System.out.println("PutItem succeeded: " + year + " " + title);

			} catch (Exception e) {
				System.err.println("Unable to add movie: " + year + " " + title);
				System.err.println(e.getMessage());
				break;
			}
		}
		parser.close();
	}

	private static void createTable() {

		try {

			AWSCredentials credentials = new BasicAWSCredentials("AKIAJNEH32XXZTKK37IQ",
					"bQZMynrjQZr++pEGZWmzocPYBfEWToZBoIgMnnaI");

			AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(credentials)).withRegion(Regions.AP_SOUTH_1)
					.build();
			DynamoDB dynamoDB = new DynamoDB(client);

			String tableName = "Movies";

			System.out.println("Attempting to create table; please wait...");
			Table table = dynamoDB.createTable(tableName, Arrays.asList(new KeySchemaElement("year", KeyType.HASH), // Partition
																													// key
					new KeySchemaElement("title", KeyType.RANGE)), // Sort key
					Arrays.asList(new AttributeDefinition("year", ScalarAttributeType.N),
							new AttributeDefinition("title", ScalarAttributeType.S)),
					new ProvisionedThroughput(10L, 10L));
			table.waitForActive();
			System.out.println("Success.  Table status: " + table.getDescription().getTableStatus());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void additem() {
		try {

			AWSCredentials credentials = new BasicAWSCredentials("AKIAJNEH32XXZTKK37IQ",
					"bQZMynrjQZr++pEGZWmzocPYBfEWToZBoIgMnnaI");

			AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(credentials)).withRegion(Regions.AP_SOUTH_1)
					.build();
			DynamoDB dynamoDB = new DynamoDB(client);

			String tableName = "ajaymind";

			Table table = dynamoDB.getTable(tableName);

			String movieName="Raja";
			// Build a list of related items
			List<Number> relatedItems = new ArrayList<Number>();
			relatedItems.add(341);
			relatedItems.add(472);
			relatedItems.add(649);

			// Build a map of product pictures
			Map<String, String> pictures = new HashMap<String, String>();
			pictures.put("FrontView", "http://example.com/products/123_front.jpg");
			pictures.put("RearView", "http://example.com/products/123_rear.jpg");
			pictures.put("SideView", "http://example.com/products/123_left_side.jpg");

			// Build a map of product reviews
			Map<String, List<String>> reviews = new HashMap<String, List<String>>();

			List<String> fiveStarReviews = new ArrayList<String>();
			fiveStarReviews.add("Excellent! Can't recommend it highly enough!  Buy it!");
			fiveStarReviews.add("Do yourself a favor and buy this");
			reviews.put("FiveStar", fiveStarReviews);

			List<String> oneStarReviews = new ArrayList<String>();
			oneStarReviews.add("Terrible product!  Do not buy this.");
			reviews.put("OneStar", oneStarReviews);

			ItemPic itemPic=new ItemPic();
			itemPic.setMovieName(movieName);
			itemPic.setPictures(pictures);
			itemPic.setRelatedItems(relatedItems);
			itemPic.setReviews(reviews);
			
			ObjectMapper objectMapper = new ObjectMapper();
			// Write the item to the table
			
			String json = objectMapper.writeValueAsString(itemPic);
			
			// Build the item90
			/*Item item = new Item().withPrimaryKey("Id", 123).withString("MovieName", json)
					.withList("RelatedItems", relatedItems).withMap("Pictures", pictures).withMap("Reviews", reviews);
*/
			
			Item item = new Item().withPrimaryKey("Id", 123).withJSON("requestPayload", json);

			System.out.println(json);
			
			PutItemOutcome outcome = table.putItem(item);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
