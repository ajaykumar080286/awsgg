package begineerstutor.s3_bucket_example;

import java.util.List;
import java.util.Map;

public class ItemPic {

	private String movieName;
	private List<Number> relatedItems;
	Map<String, String> pictures;

	Map<String, List<String>> reviews;

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public List<Number> getRelatedItems() {
		return relatedItems;
	}

	public void setRelatedItems(List<Number> relatedItems) {
		this.relatedItems = relatedItems;
	}

	public Map<String, String> getPictures() {
		return pictures;
	}

	public void setPictures(Map<String, String> pictures) {
		this.pictures = pictures;
	}

	public Map<String, List<String>> getReviews() {
		return reviews;
	}

	public void setReviews(Map<String, List<String>> reviews) {
		this.reviews = reviews;
	}
	
	
	

}
