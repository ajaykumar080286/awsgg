package begineerstutor.s3_bucket_example;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.partitions.model.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.TableCollection;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ListTablesResult;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.TableDescription;

public class DynamoDb {

	public static void main(String[] args) throws Exception {

		//create table
		// createTable();
		// table description

	//	tableDesc();

		// tableUpdate();
		// tableDesc();
		//tableDelete();
		 listOftable();
	}

	private static void createTable() {

		try {

			AWSCredentials credentials = new BasicAWSCredentials("AKIAJNEH32XXZTKK37IQ",
					"bQZMynrjQZr++pEGZWmzocPYBfEWToZBoIgMnnaI");

			AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(credentials)).withRegion(Regions.AP_SOUTH_1)
					.build();
			DynamoDB dynamoDB = new DynamoDB(client);

			String tableName = "ajaymind";
			List<AttributeDefinition> attributeDefinitions = new ArrayList<AttributeDefinition>();
			attributeDefinitions.add(new AttributeDefinition().withAttributeName("Id").withAttributeType("N"));

			List<KeySchemaElement> keySchema = new ArrayList<KeySchemaElement>();
			keySchema.add(new KeySchemaElement().withAttributeName("Id").withKeyType(KeyType.HASH));

			CreateTableRequest request = new CreateTableRequest().withTableName(tableName).withKeySchema(keySchema)
					.withAttributeDefinitions(attributeDefinitions).withProvisionedThroughput(
							new ProvisionedThroughput().withReadCapacityUnits(5L).withWriteCapacityUnits(6L));

			Table table = dynamoDB.createTable(request);

			table.waitForActive();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void tableDesc() {

		try {

			AWSCredentials credentials = new BasicAWSCredentials("AKIAJNEH32XXZTKK37IQ",
					"bQZMynrjQZr++pEGZWmzocPYBfEWToZBoIgMnnaI");

			AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(credentials)).withRegion(Regions.AP_SOUTH_1)
					.build();
			DynamoDB dynamoDB = new DynamoDB(client);

			String tableName = "ajaymind";
			TableDescription tableDescription = dynamoDB.getTable(tableName).describe();

			System.out.printf("%s: %s \t ReadCapacityUnits: %d \t WriteCapacityUnits: %d",
					tableDescription.getTableStatus(), tableDescription.getTableName(),
					tableDescription.getProvisionedThroughput().getReadCapacityUnits(),
					tableDescription.getProvisionedThroughput().getWriteCapacityUnits());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void tableUpdate() {
		try {

			AWSCredentials credentials = new BasicAWSCredentials("AKIAJNEH32XXZTKK37IQ",
					"bQZMynrjQZr++pEGZWmzocPYBfEWToZBoIgMnnaI");

			AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(credentials)).withRegion(Regions.AP_SOUTH_1)
					.build();
			DynamoDB dynamoDB = new DynamoDB(client);

			String tableName = "ajaymind";

			Table table = dynamoDB.getTable(tableName);

			ProvisionedThroughput provisionedThroughput = new ProvisionedThroughput().withReadCapacityUnits(15L)
					.withWriteCapacityUnits(12L);

			table.updateTable(provisionedThroughput);

			table.waitForActive();
			System.out.println("success");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void tableDelete() {
		try {

			AWSCredentials credentials = new BasicAWSCredentials("AKIAJNEH32XXZTKK37IQ",
					"bQZMynrjQZr++pEGZWmzocPYBfEWToZBoIgMnnaI");

			AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(credentials)).withRegion(Regions.AP_SOUTH_1)
					.build();
			DynamoDB dynamoDB = new DynamoDB(client);

			String tableName = "ajaymind";
			
			Table table = dynamoDB.getTable(tableName);

			table.delete();

			table.waitForDelete();
			System.out.println("deleted");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void listOftable() {
		try {

			AWSCredentials credentials = new BasicAWSCredentials("AKIAJNEH32XXZTKK37IQ",
					"bQZMynrjQZr++pEGZWmzocPYBfEWToZBoIgMnnaI");

			AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(credentials)).withRegion(Regions.AP_SOUTH_1)
					.build();
			DynamoDB dynamoDB = new DynamoDB(client);

			//String tableName = "ajaymind";
			
			TableCollection<ListTablesResult> tables = dynamoDB.listTables();
			Iterator<Table> iterator = tables.iterator();

			while (iterator.hasNext()) {
			    Table table = iterator.next();
			    System.out.println(table.getTableName());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
