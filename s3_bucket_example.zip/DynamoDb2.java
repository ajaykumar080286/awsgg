package begineerstutor.s3_bucket_example;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.PutItemOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DynamoDb2 {
	public static void main(String[] args) throws Exception {

		additem();
	}

	private static void additem() {
		try {

			AWSCredentials credentials = new BasicAWSCredentials("AKIAJNEH32XXZTKK37IQ",
					"bQZMynrjQZr++pEGZWmzocPYBfEWToZBoIgMnnaI");

			AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(credentials)).withRegion(Regions.AP_SOUTH_1)
					.build();
			DynamoDB dynamoDB = new DynamoDB(client);

			String tableName = "ajaymind";

			Table table = dynamoDB.getTable(tableName);

			ObjectMapper objectMapper = new ObjectMapper();
			// Write the item to the table

			File file = new File("E://DOWNLOADS/moviedata.json");
			ItemPic itemPic = objectMapper.readValue(file, ItemPic.class);

			String json = objectMapper.writeValueAsString(itemPic);

			MyResponse response = new MyResponse();
			response.setMsg("generate");
			response.setStatus("200");

			Item item = new Item().withPrimaryKey("Id", 123).withJSON("requestPayload", json)
					.withJSON("responsePayload", objectMapper.writeValueAsString(response));

			System.out.println(json);

			PutItemOutcome outcome = table.putItem(item);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
